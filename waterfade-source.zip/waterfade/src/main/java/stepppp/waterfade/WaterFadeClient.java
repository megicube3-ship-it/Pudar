package stepppp.waterfade;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.FluidTags;
import stepppp.waterfade.mixin.GameRendererAccessor;

/**
 * Efek kamera luntur setelah keluar dari air.
 * exitWater meluruh eksponensial dengan half-life 5 detik (sama seperti
 * smooth(..., 0.0, 5.0) di shader), efek mati saat nilainya <= 0.01 (+/- 33 detik).
 * Nilai tiap langkah (tiap 2 tick) ada di post_effect/exit_XXX.json.
 */
public class WaterFadeClient implements ClientModInitializer {

    private static final int TICKS_PER_STEP = 2;
    private static final int STEPS = 330; // harus sama dengan jumlah file exit_XXX.json

    private static boolean wasUnderwater = false;
    private static int ticksSinceExit = -1; // -1 = efek tidak aktif
    private static int activeStep = -1;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(WaterFadeClient::tick);
    }

    private static void tick(Minecraft mc) {
        if (mc.player == null) {
            wasUnderwater = false;
            ticksSinceExit = -1;
            apply(mc, -1);
            return;
        }
        boolean under = mc.player.isEyeInFluid(FluidTags.WATER);
        if (under) {
            ticksSinceExit = -1;           // di dalam air: tidak ada distorsi
        } else if (wasUnderwater) {
            ticksSinceExit = 0;            // baru keluar: exitWater = 1
        } else if (ticksSinceExit >= 0) {
            ticksSinceExit++;
        }
        wasUnderwater = under;

        int step = ticksSinceExit < 0 ? -1 : ticksSinceExit / TICKS_PER_STEP;
        if (step >= STEPS) { step = -1; ticksSinceExit = -1; }
        apply(mc, step);
    }

    private static void apply(Minecraft mc, int step) {
        if (step == activeStep) return;
        activeStep = step;
        if (step >= 0) {
            ((GameRendererAccessor) mc.gameRenderer).waterfade$setPostEffect(
                    Identifier.fromNamespaceAndPath("waterfade", String.format("exit_%03d", step)));
        } else {
            mc.gameRenderer.clearPostEffect();
        }
    }
}
