package com.narutohover;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

public class NarutoHoverClient implements ClientModInitializer {
	// File suara: assets/narutohover/sounds/hover.ogg (didaftarkan di sounds.json)
	public static final SoundEvent HOVER =
			SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("narutohover", "hover"));

	private AbstractWidget lastHovered = null;

	@Override
	public void onInitializeClient() {
		ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
			lastHovered = null;

			ScreenEvents.afterRender(screen).register((s, graphics, mouseX, mouseY, tickDelta) -> {
				AbstractWidget current = null;
				for (AbstractWidget w : Screens.getButtons(s)) {
					if (w.visible && w.active && w.isHovered()) {
						current = w;
						break;
					}
				}
				if (current != null && current != lastHovered) {
					Minecraft.getInstance().getSoundManager()
							.play(SimpleSoundInstance.forUI(HOVER, 1.0f, 1.0f));
				}
				lastHovered = current;
			});
		});
	}
}
