package com.bloodclient;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Data hasil konversi datapack Blood N' Particles asli (bnp_data.json). */
public final class BloodData {
    public static final class Cond {
        String type; boolean tag;
        int baby = -1, size = -1, variant = -1;
        boolean rolling;
        boolean hasRb, hasDt;
        int rbLo, rbHi, dtLo, dtHi;
    }

    public static final class Op {
        String k;
        Cond c;
        int n;                       // rand
        // decal / drop
        float[] m; boolean hasRot; float rotY, rotX; boolean hasBr; int brBlock, brSky;
        boolean noPlayer, align; double oy; String id, model, land;
        // particle
        JsonObject spec; double dx, dy, dz, spd; int count;
        Object parsedParticle;
        // sound
        String snd; boolean self; double maxd; float vol, pitch;
        // call
        String fn;
    }

    public static final Map<String, List<Op>> FNS = new HashMap<>();
    public static final Map<String, Set<String>> TAGS = new HashMap<>();
    public static final Set<String> NO_BLOODED = new HashSet<>();
    public static final Set<String> THIN_IDS = new HashSet<>();
    public static final Set<String> THIN_TAGS = new HashSet<>();
    private static boolean loaded = false;

    static synchronized void load() {
        if (loaded) return;
        loaded = true;
        try (Reader r = new InputStreamReader(BloodData.class.getResourceAsStream("/bnp_data.json"), StandardCharsets.UTF_8)) {
            JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
            for (var e : root.getAsJsonObject("tags").entrySet()) {
                Set<String> s = new HashSet<>();
                for (JsonElement x : e.getValue().getAsJsonArray()) s.add(x.getAsString());
                TAGS.put(e.getKey(), s);
            }
            for (JsonElement x : root.getAsJsonArray("noBlooded")) NO_BLOODED.add(x.getAsString());
            for (JsonElement x : root.getAsJsonArray("thinIds")) THIN_IDS.add(x.getAsString());
            for (JsonElement x : root.getAsJsonArray("thinTags")) THIN_TAGS.add(x.getAsString());
            for (var e : root.getAsJsonObject("fns").entrySet()) {
                List<Op> ops = new ArrayList<>();
                for (JsonElement x : e.getValue().getAsJsonArray()) ops.add(parseOp(x.getAsJsonObject()));
                FNS.put(e.getKey(), ops);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static int[] range(JsonArray a) { return new int[] { a.get(0).getAsInt(), a.get(1).getAsInt() }; }

    private static Cond parseCond(JsonObject o) {
        if (o == null || o.size() == 0) return null;
        Cond c = new Cond();
        if (o.has("type")) { c.type = o.get("type").getAsString(); c.tag = o.get("tag").getAsBoolean(); }
        if (o.has("baby")) c.baby = o.get("baby").getAsInt();
        if (o.has("size")) c.size = o.get("size").getAsInt();
        if (o.has("variant")) c.variant = o.get("variant").getAsInt();
        if (o.has("rolling")) c.rolling = true;
        if (o.has("rb")) { int[] r = range(o.getAsJsonArray("rb")); c.hasRb = true; c.rbLo = r[0]; c.rbHi = r[1]; }
        if (o.has("dt")) { int[] r = range(o.getAsJsonArray("dt")); c.hasDt = true; c.dtLo = r[0]; c.dtHi = r[1]; }
        return c;
    }

    private static Op parseOp(JsonObject o) {
        Op p = new Op();
        p.k = o.get("k").getAsString();
        if (o.has("c")) p.c = parseCond(o.getAsJsonObject("c"));
        switch (p.k) {
            case "rand" -> p.n = o.get("n").getAsInt();
            case "decal" -> {
                JsonArray m = o.getAsJsonArray("m");
                p.m = new float[16];
                for (int i = 0; i < 16; i++) p.m[i] = m.get(i).getAsFloat();
                if (o.has("rot")) { p.hasRot = true; p.rotY = o.getAsJsonArray("rot").get(0).getAsFloat(); p.rotX = o.getAsJsonArray("rot").get(1).getAsFloat(); }
                if (o.has("br")) { p.hasBr = true; p.brBlock = o.getAsJsonArray("br").get(0).getAsInt(); p.brSky = o.getAsJsonArray("br").get(1).getAsInt(); }
                p.noPlayer = o.get("noPlayer").getAsBoolean();
                p.align = o.get("align").getAsBoolean();
                p.oy = o.get("oy").getAsDouble();
                p.id = o.get("id").getAsString();
                p.model = o.get("model").getAsString();
            }
            case "drop" -> {
                p.oy = o.get("oy").getAsDouble();
                p.id = o.get("id").getAsString();
                p.model = o.get("model").getAsString();
                p.land = o.get("land").getAsString();
            }
            case "call" -> p.fn = o.get("fn").getAsString();
            case "particle" -> {
                p.spec = o.getAsJsonObject("spec");
                p.oy = o.get("oy").getAsDouble();
                p.dx = o.get("dx").getAsDouble(); p.dy = o.get("dy").getAsDouble(); p.dz = o.get("dz").getAsDouble();
                p.spd = o.get("spd").getAsDouble(); p.count = o.get("n").getAsInt();
            }
            case "sound" -> {
                p.snd = o.get("snd").getAsString();
                p.self = o.get("self").getAsBoolean();
                p.maxd = o.get("maxd").getAsDouble();
                p.vol = o.get("vol").getAsFloat(); p.pitch = o.get("pitch").getAsFloat();
            }
            default -> { }
        }
        return p;
    }
}
