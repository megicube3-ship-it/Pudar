package com.bloodclient.mixin;

import com.mojang.math.Transformation;
import net.minecraft.util.Brightness;
import net.minecraft.world.entity.Display;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(Display.class)
public interface DisplayAccessor {
    @Invoker("setTransformation")
    void bnp$setTransformation(Transformation t);

    @Invoker("setBrightnessOverride")
    void bnp$setBrightnessOverride(Brightness b);
}
