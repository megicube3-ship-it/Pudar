package stepppp.waterfade;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.FluidTags;
import stepppp.waterfade.mixin.GameRendererAccessor;

/**
 * Efek kamera luntur setelah keluar dari air.
 * Rumus distorsi ada di assets/waterfade/shaders/post/exitwater.fsh.
 * Kekuatan efek (1 -> 0) dipilih lewat 50 file post_effect/exit_XX.json.
 */
public class WaterFadeClient implements ClientModInitializer {

    private static final int DURATION = 100; // tick, 100 = 5 detik
    private static final int STEPS = 50;     // harus sama dengan jumlah file exit_XX.json

    private static int timer = 0;
    private static boolean wasUnderwater = false;
    private static int activeStep = 0;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(WaterFadeClient::tick);
    }

    private static void tick(Minecraft mc) {
        if (mc.player == null) {
            timer = 0;
            wasUnderwater = false;
            apply(mc, 0);
            return;
        }
        boolean under = mc.player.isEyeInFluid(FluidTags.WATER);
        if (wasUnderwater && !under) timer = DURATION;
        if (under) timer = 0;
        else if (timer > 0) timer--;
        wasUnderwater = under;

        int step = timer <= 0 ? 0 : Math.max(1, Math.round((float) timer / DURATION * STEPS));
        apply(mc, step);
    }

    private static void apply(Minecraft mc, int step) {
        if (step == activeStep) return;
        activeStep = step;
        if (step > 0) {
            String name = String.format("exit_%02d", step);
            ((GameRendererAccessor) mc.gameRenderer)
                    .waterfade$setPostEffect(Identifier.fromNamespaceAndPath("waterfade", name));
        } else {
            mc.gameRenderer.clearPostEffect();
        }
    }
}
