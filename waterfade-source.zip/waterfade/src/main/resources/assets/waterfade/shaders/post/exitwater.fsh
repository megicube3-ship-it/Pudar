#version 330

uniform sampler2D InSampler;
uniform sampler2D NoiseSampler;

layout(std140) uniform WaterConfig {
    float Exit;
};

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec2 size = vec2(textureSize(InSampler, 0));
    float aspect = size.x / size.y;
    float e = clamp(Exit, 0.0, 1.0);

    // noise digeser naik seiring waktu, makin lama makin sedikit area yang terdistorsi
    vec2 scale = vec2(0.5, 0.25 + e * e * 0.25) * vec2(aspect, 1.0);
    vec2 nuv = fract((texCoord - vec2(0.0, e)) * scale);
    float drops = texture(NoiseSampler, nuv).r;
    drops = sqrt(min(max(drops - (1.0 - sqrt(e)) * 0.7, 0.0) * (1.0 + e), 1.0)) * 0.3;

    // zoom dari tengah layar sebesar mask
    vec2 zuv = 0.5 + (texCoord - 0.5) * (1.0 - drops);
    fragColor = vec4(texture(InSampler, zuv).rgb, 1.0);
}
