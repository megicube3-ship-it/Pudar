package com.bloodclient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.bloodclient.BloodData.Cond;
import com.bloodclient.BloodData.Op;
import com.bloodclient.mixin.DisplayAccessor;
import com.bloodclient.mixin.ItemDisplayAccessor;
import com.google.gson.JsonElement;
import com.mojang.math.Transformation;
import com.mojang.serialization.JsonOps;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.RegistryOps;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Brightness;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.armadillo.Armadillo;
import net.minecraft.world.entity.animal.axolotl.Axolotl;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Slime;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Port client-side dari datapack Blood N' Particles (RenovatedStudios, MIT).
 * Logika, model, tekstur, ukuran, partikel dan suara sama dengan datapack aslinya,
 * tapi semua dibuat lokal di klien sehingga jalan di server publik tanpa mod di server.
 */
public final class BloodClient {
    private static final int MAX_DECALS = 400;

    private static final class Ctx {
        double x, y, z; boolean aligned; String selfType; LivingEntity self;
        int rb; int dt; boolean isMe;
    }

    private static final class Decal {
        Display.ItemDisplay e; Transformation base; boolean noPlayer; int age;
    }

    private static final class Drop {
        ItemEntity e; String land; int age;
    }

    private static final List<Decal> DECALS = new ArrayList<>();
    private static final List<Drop> DROPS = new ArrayList<>();
    private static final Map<Integer, Integer> LAST_HURT = new HashMap<>();
    private static final Map<Integer, Float> LAST_HEALTH = new HashMap<>();
    private static final Map<String, ItemStack> STACKS = new HashMap<>();
    private static final Map<Object, Boolean> THIN_CACHE = new HashMap<>();
    private static ClientLevel current;
    private static int nextId = -2_000_000;
    private static int clean;

    private BloodClient() {}

    // ------------------------------------------------------------------ tick
    public static void tick(Minecraft mc) {
        BloodData.load();
        ClientLevel level = mc.level;
        Player me = mc.player;
        if (level == null || me == null) { reset(); return; }
        if (level != current) { reset(); current = level; }

        List<Object[]> pending = new ArrayList<>();

        // 1) Pemain kena damage (.dTaken = damage x10) - semua pemain, sama seperti @a di datapack
        for (Player p : level.players()) {
            float hp = p.getHealth();
            Float prev = LAST_HEALTH.put(p.getId(), hp);
            if (prev != null && hp < prev) {
                int dt = Math.round((prev - hp) * 10f);
                if (dt >= 1) pending.add(new Object[] { p, dt });
            }
        }

        // 2) Mob kena damage: datapack memakai HurtTime == 1
        for (Entity e : level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity le) || e instanceof Player) continue;
            int cur = le.hurtTime;
            Integer prev = LAST_HURT.put(le.getId(), cur);
            if (cur == 1 && (prev == null || prev != 1) && le.distanceToSqr(me) <= 32 * 32) {
                String type = typePath(le);
                if (!BloodData.NO_BLOODED.contains(type)) pending.add(new Object[] { le, -1 });
            }
        }

        for (Object[] pe : pending) {
            LivingEntity le = (LivingEntity) pe[0];
            int dt = (Integer) pe[1];
            Ctx cx = new Ctx();
            cx.x = le.getX(); cx.y = le.getY(); cx.z = le.getZ();
            cx.self = le; cx.selfType = typePath(le);
            if (dt >= 1) {
                cx.dt = dt; cx.isMe = (le == me); cx.selfType = "player";
                run(mc, level, "particles_n_sounds", cx);
                run(mc, level, "blood_sizes", cx);
            } else {
                cx.y = Math.floor(cx.y); cx.aligned = true;
                run(mc, level, "entity_blood/entities_select", cx);
            }
        }

        tickDecals(level);
        tickDrops(mc, level);

        if (++clean > 600) { clean = 0; LAST_HURT.clear(); }
    }

    private static void reset() {
        for (Decal d : DECALS) d.e.discard();
        for (Drop d : DROPS) d.e.discard();
        DECALS.clear(); DROPS.clear(); LAST_HURT.clear(); LAST_HEALTH.clear();
        STACKS.clear(); current = null;
    }

    private static String typePath(Entity e) {
        var key = BuiltInRegistries.ENTITY_TYPE.getKey(e.getType());
        return key.getPath();
    }

    // ------------------------------------------------------------- executor
    private static void run(Minecraft mc, ClientLevel level, String fn, Ctx cx) {
        List<Op> ops = BloodData.FNS.get(fn);
        if (ops == null) return;
        for (Op op : ops) {
            if (!"rand".equals(op.k) && !test(op.c, cx)) continue;
            switch (op.k) {
                case "rand" -> cx.rb = 1 + level.getRandom().nextInt(op.n);
                case "call" -> run(mc, level, op.fn, cx);
                case "decal" -> spawnDecal(level, op, cx);
                case "drop" -> spawnDrop(level, op, cx);
                case "particle" -> spawnParticles(mc, level, op, cx);
                case "sound" -> playSound(mc, level, op, cx);
                default -> { }
            }
        }
    }

    private static boolean test(Cond c, Ctx x) {
        if (c == null) return true;
        if (c.type != null) {
            if (c.tag) {
                var s = BloodData.TAGS.get(c.type);
                if (s == null || !s.contains(x.selfType)) return false;
            } else if (!c.type.equals(x.selfType)) return false;
        }
        if (c.baby >= 0 && !(x.self != null && x.self.isBaby() == (c.baby == 1))) return false;
        if (c.size >= 0 && !(x.self instanceof Slime s && s.getSize() == c.size)) return false;
        if (c.variant >= 0 && !(x.self instanceof Axolotl a && a.getVariant().getId() == c.variant)) return false;
        if (c.rolling && !(x.self instanceof Armadillo a && a.isScared())) return false;
        if (c.hasRb && (x.rb < c.rbLo || x.rb > c.rbHi)) return false;
        if (c.hasDt && (x.dt < c.dtLo || x.dt > c.dtHi)) return false;
        return true;
    }

    // ---------------------------------------------------------------- decals
    private static ItemStack stack(ClientLevel level, String id, String model) {
        String key = id + "|" + model;
        ItemStack s = STACKS.get(key);
        if (s != null) return s;
        com.google.gson.JsonObject o = new com.google.gson.JsonObject();
        o.addProperty("id", id);
        o.addProperty("count", 1);
        com.google.gson.JsonObject comps = new com.google.gson.JsonObject();
        comps.addProperty("minecraft:item_model", model);
        o.add("components", comps);
        RegistryOps<JsonElement> ops = RegistryOps.create(JsonOps.INSTANCE, level.registryAccess());
        s = ItemStack.CODEC.parse(ops, o).result().orElse(ItemStack.EMPTY);
        STACKS.put(key, s);
        return s;
    }

    private static void spawnDecal(ClientLevel level, Op op, Ctx cx) {
        double y = (op.align || cx.aligned) ? Math.floor(cx.y) : cx.y;
        y += op.oy;
        ItemStack st = stack(level, op.id, op.model);
        if (st.isEmpty()) return;

        Display.ItemDisplay d = new Display.ItemDisplay(EntityType.ITEM_DISPLAY, level);
        d.setId(--nextId);
        d.setPos(cx.x, y, cx.z);
        d.xo = cx.x; d.yo = y; d.zo = cx.z;
        if (op.hasRot) {
            d.setYRot(op.rotY); d.setXRot(op.rotX);
            d.yRotO = op.rotY; d.xRotO = op.rotX;
        }
        float[] a = op.m;
        Matrix4f m = new Matrix4f(
                a[0], a[4], a[8], a[12],
                a[1], a[5], a[9], a[13],
                a[2], a[6], a[10], a[14],
                a[3], a[7], a[11], a[15]);
        Transformation base = new Transformation(m);
        ((ItemDisplayAccessor) d).bnp$setItemStack(st);
        ((DisplayAccessor) d).bnp$setTransformation(base);
        if (op.hasBr) ((DisplayAccessor) d).bnp$setBrightnessOverride(new Brightness(op.brBlock, op.brSky));
        level.addEntity(d);

        Decal dc = new Decal();
        dc.e = d; dc.base = base; dc.noPlayer = op.noPlayer;
        DECALS.add(dc);
        while (DECALS.size() > MAX_DECALS) DECALS.remove(0).e.discard();
    }

    private static void tickDecals(ClientLevel level) {
        Iterator<Decal> it = DECALS.iterator();
        while (it.hasNext()) {
            Decal d = it.next();
            if (d.e.isRemoved()) { it.remove(); continue; }
            d.age++;
            // Tag #blood_collition: turun 0.5 per tick selama blok di bawahnya "tipis"/kosong
            double x = d.e.getX(), y = d.e.getY(), z = d.e.getZ();
            if (y > -70) {
                BlockPos bp = BlockPos.containing(x, y - 0.6, z);
                if (level.hasChunkAt(bp) && isThin(level.getBlockState(bp))) {
                    d.e.setPos(x, y - 0.5, z);
                }
            }
            int start = d.noPlayer ? 90 : 170;
            int end = d.noPlayer ? 120 : 200;
            if (d.age >= end) { d.e.discard(); it.remove(); continue; }
            if (d.age >= start) {
                float f = Math.max(0f, 1f - (d.age - start) / 30f);
                Transformation t = new Transformation(d.base.getTranslation(), d.base.getLeftRotation(),
                        new Vector3f(d.base.getScale()).mul(f), d.base.getRightRotation());
                ((DisplayAccessor) d.e).bnp$setTransformation(t);
            }
        }
    }

    private static boolean isThin(BlockState s) {
        if (s.isAir()) return true;
        Boolean c = THIN_CACHE.get(s.getBlock());
        if (c != null) return c;
        boolean r = BloodData.THIN_IDS.contains(BuiltInRegistries.BLOCK.getKey(s.getBlock()).getPath());
        if (!r) {
            for (String t : BloodData.THIN_TAGS) {
                if (tag(s, t)) { r = true; break; }
            }
        }
        THIN_CACHE.put(s.getBlock(), r);
        return r;
    }

    private static boolean tag(BlockState s, String t) {
        return switch (t) {
            case "banners" -> s.is(BlockTags.BANNERS);
            case "beds" -> s.is(BlockTags.BEDS);
            case "buttons" -> s.is(BlockTags.BUTTONS);
            case "candles" -> s.is(BlockTags.CANDLES);
            case "coral_plants" -> s.is(BlockTags.CORAL_PLANTS);
            case "corals" -> s.is(BlockTags.CORALS);
            case "crops" -> s.is(BlockTags.CROPS);
            case "doors" -> s.is(BlockTags.DOORS);
            case "fence_gates" -> s.is(BlockTags.FENCE_GATES);
            case "fences" -> s.is(BlockTags.FENCES);
            case "flowers" -> s.is(BlockTags.FLOWERS);
            case "pressure_plates" -> s.is(BlockTags.PRESSURE_PLATES);
            case "rails" -> s.is(BlockTags.RAILS);
            case "saplings" -> s.is(BlockTags.SAPLINGS);
            case "signs" -> s.is(BlockTags.SIGNS);
            case "trapdoors" -> s.is(BlockTags.TRAPDOORS);
            case "wall_corals" -> s.is(BlockTags.WALL_CORALS);
            case "wall_signs" -> s.is(BlockTags.WALL_SIGNS);
            case "walls" -> s.is(BlockTags.WALLS);
            default -> false;
        };
    }

    // ----------------------------------------------------------- drop items
    private static void spawnDrop(ClientLevel level, Op op, Ctx cx) {
        ItemStack st = stack(level, op.id, op.model);
        if (st.isEmpty()) return;
        double y = (cx.aligned ? Math.floor(cx.y) : cx.y) + op.oy;
        ItemEntity ie = new ItemEntity(level, cx.x, y, cx.z, st);
        ie.setDeltaMovement(Vec3.ZERO);
        ie.setId(--nextId);
        level.addEntity(ie);
        Drop d = new Drop();
        d.e = ie; d.land = op.land;
        DROPS.add(d);
    }

    private static void tickDrops(Minecraft mc, ClientLevel level) {
        List<Drop> landed = new ArrayList<>();
        Iterator<Drop> it = DROPS.iterator();
        while (it.hasNext()) {
            Drop d = it.next();
            d.age++;
            if (d.e.isRemoved()) { it.remove(); continue; }
            if ((d.age > 2 && d.e.onGround()) || d.age > 400) { landed.add(d); it.remove(); }
        }
        for (Drop d : landed) {
            Ctx cx = new Ctx();
            cx.x = d.e.getX(); cx.y = d.e.getY(); cx.z = d.e.getZ();
            cx.selfType = "item";
            d.e.discard();
            run(mc, level, d.land, cx);
        }
    }

    // ----------------------------------------------------- particles & sound
    private static void spawnParticles(Minecraft mc, ClientLevel level, Op op, Ctx cx) {
        if (op.parsedParticle == null) {
            RegistryOps<JsonElement> ops = RegistryOps.create(JsonOps.INSTANCE, level.registryAccess());
            op.parsedParticle = ParticleTypes.CODEC.parse(ops, op.spec).result().orElse(null);
            if (op.parsedParticle == null) op.parsedParticle = Boolean.FALSE;
        }
        if (!(op.parsedParticle instanceof ParticleOptions po)) return;
        RandomSource r = level.getRandom();
        double bx = cx.x, by = (cx.aligned ? Math.floor(cx.y) : cx.y) + op.oy, bz = cx.z;
        for (int i = 0; i < op.count; i++) {
            mc.particleEngine.createParticle(po,
                    bx + r.nextGaussian() * op.dx, by + r.nextGaussian() * op.dy, bz + r.nextGaussian() * op.dz,
                    r.nextGaussian() * op.spd, r.nextGaussian() * op.spd, r.nextGaussian() * op.spd);
        }
    }

    private static void playSound(Minecraft mc, ClientLevel level, Op op, Ctx cx) {
        if (op.self && !cx.isMe) return;
        double y = cx.aligned ? Math.floor(cx.y) : cx.y;
        if (!op.self && mc.player.distanceToSqr(cx.x, y, cx.z) > op.maxd * op.maxd) return;
        SoundEvent ev = switch (op.snd) {
            case "block.slime_block.break" -> SoundEvents.SLIME_BLOCK_BREAK;
            case "block.honey_block.break" -> SoundEvents.HONEY_BLOCK_BREAK;
            default -> null;
        };
        if (ev == null) return;
        level.playLocalSound(cx.x, y, cx.z, ev, op.self ? SoundSource.PLAYERS : SoundSource.BLOCKS, op.vol, op.pitch, false);
    }
}
