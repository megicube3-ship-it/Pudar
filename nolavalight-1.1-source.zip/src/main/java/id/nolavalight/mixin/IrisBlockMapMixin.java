package id.nolavalight.mixin;

import id.nolavalight.LavaLightFix;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Iris: tabel BlockState -> id (dari block.properties shader pack) dibuat di sini.
 * Setelah dibuat, lava cauldron dibuang supaya shader tidak memperlakukannya sebagai lampu.
 * Pseudo = aman kalau Iris tidak terpasang / nama class berbeda (mixin dilewati diam-diam).
 */
@Pseudo
@Mixin(targets = "net.irisshaders.iris.shaderpack.materialmap.BlockMaterialMapping", remap = false)
public class IrisBlockMapMixin {
    @Inject(method = "createBlockStateIdMap", at = @At("RETURN"), remap = false, require = 0)
    private static void nolavalight$strip(CallbackInfoReturnable<Object> cir) {
        LavaLightFix.stripFromShaderMap(cir.getReturnValue());
    }
}
